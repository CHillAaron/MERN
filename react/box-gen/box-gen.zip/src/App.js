import './App.css';
import Form from './components/boxForm'

function App() {
  return (
    <div className="App">
      <h1>test1</h1>
      <Form/>
    </div>
  );
}

export default App;
