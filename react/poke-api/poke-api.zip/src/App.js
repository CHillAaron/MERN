import './App.css';
import Poke from './components/poke.jsx'


function App() {
  return (
    <div className="App">
      <Poke></Poke>
    </div>
  );
}

export default App;
